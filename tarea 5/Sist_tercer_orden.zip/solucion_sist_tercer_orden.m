clc
clear

[T,Z]=ode45(@sist_tercer_orden,[0:0.1:5],[0 0 0]);
%C=[1 0 0];  %Matriz C del sistema
%y=C*x=Z_1; Salida del sistema
figure;
plot(T,Z(:,1));
xlabel('Tiempo [s]');
ylabel('x_1');
